*RENware Software Systems*    
**Software Development Methodology**

Version: 0.4.10    
Release date: 220415

***

# Frequently Asked Questions

**Table of Content**

[TOC]

<small>
Note: Questions will be found as "Headings" to be easily find on table of content followed immediately by a sub-heading with answer.
</small>

## General

### Q: Can methodology be applied outside company / for other projects?

Answer: The **SDEVEN Methodology is** a *copyright (C) of RENware* Software Systems company. So, the answer is yes, if IT IS ***LICENSED*** for the owner of respective project.

## Content
### Q: 130-SKIT activities and information appears in more places

**Answer**: There are deliverables that are intended with **external** destination and others intended for **internal** audience (only inside the project. 130-SKIT is an external audience category of deliverable, the other being project internal documents in different stages assigned to more people.

--- ooo ---