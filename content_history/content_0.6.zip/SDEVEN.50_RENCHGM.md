*RENware Software Systems*    
**Software Development Methodology** 

Version: 0.4.10    
Release date: 220415

***

# Change Management (SDEVEN.50-RENCHGM)

**Table of Content**

[TOC]

## Preamble

This is about changes in software development process. The classic procedure of change management from ***Project Management discipline must be followed***.

There is no dedicated detailed procedure. Those things, very specific to software development can be found in the other sections especially in ***Practices & technical issues*** but not only.

--- ooo ---