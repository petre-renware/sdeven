<small>***RENware Software Systems***</small>

**Project Status Report**

Reference info:

* *project*: code / name
* *issued date*: yymmddhHHMM
* *issued by*: `issuer_name`

[TOC]

# Actual overview

## Brief summary ref ...

**Working / done:**

* Something with details...:
    * detail 1...
    * detail 2...
* Something without details...

**NOT working / in progress:**

* n/a or something...

## System status

* **wip** version: *the current version as in progress / not yet released...*
* last **released** version: *last released version*
* last **deployed** version: *n/a or if applicable, last deployed version* on *`server_address`*
* development server: *IP or name or whatever ID*
* inLAN opened ports:
    * *nnnnn* -* what should happen on this port...*
    * *nnnnn* -* what should happen on this port...*
* public exposed data: *the complete server address up to port `protocol://server`*
    * *nnnnn* -* what should happen on this port...*
    * *nnnnn* -* what should happen on this port...*

## Other remarks

* n/a or something...

# Actions and next steps

* n/a or something...

# Roadmap proposals

* n/a or something...

--- ooo ---
